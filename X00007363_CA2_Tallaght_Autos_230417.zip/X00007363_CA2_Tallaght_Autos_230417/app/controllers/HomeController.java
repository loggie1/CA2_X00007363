package controllers;

import play.api.Environment;
import play.mvc.*;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import views.html.*;

// Import models
import models.*;

public class HomeController extends Controller {

    private FormFactory formFactory;

    @Inject
    public HomeController(FormFactory f) {
        this.formFactory = f;
    }

    public Result index() {
        return ok(index.render());
    }

    public Result showroom() {
        return ok(showroom.render());
    }

    public Result about() {
        return ok(about.render());
    }

    public Result products() {

        List<Product> productsList = Product.findAll();
        return ok(products.render(productsList));
    }

    public Result addProduct() {

        Form<Product> addProductForm = formFactory.form(Product.class);

        return ok(addProduct.render(addProductForm));
    }

    public Result addProductSubmit() {
        Form<Product> newProductForm = formFactory.form(Product.class).bindFromRequest();

        if (newProductForm.hasErrors()) {
            return badRequest(addProduct.render(newProductForm));
        }

        Product p = newProductForm.get();

        if (p.getId() == null) {
            p.save();
        } else if (p.getId() != null) {
            p.update();
        }

        flash("success", "Product " + p.getName() + " has been created / updated");

        return redirect(controllers.routes.HomeController.products());
    }

    public Result deleteProduct(Long id) {

        Product.find.ref(id).delete();

        flash("success", "Product has been deleted");

        return redirect(routes.HomeController.products());
    }

    @Transactional
    public Result updateProduct(Long id) {

        Product p;
        Form<Product> productForm;

        try {
            p = Product.find.byId(id);

            productForm = formFactory.form(Product.class).fill(p);
        } catch (Exception ex) {
            return badRequest("error");

        }
        return ok(addProduct.render(productForm));
    }

}